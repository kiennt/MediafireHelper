var log = new Logger();

var MediafireHelper = {
  
  isLinkDownload : function() {
    var downloadBlock = document.getElementsByClassName("dl_startlink");
    if (downloadBlock == null) return false;
    if (downloadBlock.length == null) return false;
    if (downloadBlock.length < 1) return false;
    this.downloadBlock = downloadBlock[0];
    return true;
  }, 
    
  downloadLink : function() {    
 		for (var i=0; i < this.downloadBlock.children.length; i++) { 		  
 		  var thisElement = this.downloadBlock.children[i];
 		  var elementStyle = thisElement.getAttribute("style");
      if (elementStyle == "display: block; "){
        log.print("element " + i);
        var aElm = thisElement.getElementsByTagName('a');
        log.assert(aElm != null, "Cannot find a tag!!!");
        var directLink = aElm[0].getAttribute("href");
        window.location.href = (aElm[0].getAttribute("href"));
        return true;
      }
 		}
  }
};

window.addEventListener(
 	'load',
 	function(){
    if (MediafireHelper.isLinkDownload()) {
      MediafireHelper.downloadLink();
    }
 	},
 	true
);

